var head = document.getElementById("head")

head.addEventListener("click", () => {
    alert("You clicked")
})