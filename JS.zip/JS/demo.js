// This is a comment
/* 
Welcome to
the world of
Javascript programming
*/

console.log("This is to demonstrate the usage of console");